

  export const details = [
    {
      name: "Roystan",
      age: 23,
     
    },
    {
      name: "Abraham",
      age: 27,
     
    },
    {
      name: "jack",
      age: 22,
     
    },
    {
      name:"miz",
      age:33,
    
    },
    {
      name:"john",
      age:34,
  
    },
    {
      name:"yash",
      age:45,
  
    },{
      name:"michel",
      age:52,
    
    },{
      name:"reymestrio",
      age:29,
    
    },{
      name:"roman",
      age:32,
     
    },{
      name:"Mathew",
      age:52,
      
    }
  ]
